Installing Commerce Bug 3 for Magento 2
==================================================	
Thank you for your purchase!  These instructions will guide you through installing Commerce Bug into your Magento 2 system.  If you run into any problems installing your extension, please contact support and we'll do our best to help you!

    http://www.pulsestorm.net/contact-us/

Please remember, Commerce Bug (like all debugging tools) is intended for use on developer and staging systems.   Installing on a production system is **not** supported.  If circumstances force you to install into a production system, please take appropriate steps to backup your system and ensure you can restore any changes made to that system should something unexpected happen. 

Also, Commerce Bug 3 for Magento 2 now obeys settings in 

    Stores -> Configuration -> Advanced -> Developer -> Developer Client Restrictions
    
If you don't want your team to see the extension, use this setting to restrict access to your own IP  

Short Version
--------------------------------------------------
For experienced developers, here's the short version.

1. Extract the Magento 2 archive into the root folder of your system `tar -xvf Package_Commercebug_Magento2.tar `

2. Clear you cache, generation, and serialized DI folders (`var/generation/*`,  `var/cache/*`, `var/di/`)

3. Enable your module `php bin/magento module:enable Packagename_Commercebug`

4. Run module's setup scripts `php bin/magento setup:upgrade`

A longer version with context follows. 

Untar archive
--------------------------------------------------
We deliver Commerce Bug 3 as a simple `tar` archive of source files.  You can find your archive in the `magento-2` folder of the zip file you downloaded after making your purchase.  If will be named something like this following

    Packagename_Commercebug_Magento2.tar
    Companyname_Commercebug_Magento2.tar    

Make a note of the first segment of the archive name (`Packagename`, `Companyname`, etc.).  This will be different for your archive, and is the custom namespace for your module.  The remainder of this document will use a custom namespace of `Packagename`, so make sure you swap out your name for your own system.

The first step to installing Commerce Bug 3 is to extract the tar archive into the root folder of your Magento 2 system.  One way to do this is with the following command. 

    cd /path/to/my/magento/folder
    tar -xvf Package_Commercebug_Magento2.tar 

After running the above, you should see a number of files in the following folder

    app/code/Packagename/Commercebug
    
Again, remember that `Packagename` will be customized for your purchased version of Commerce Bug. 

**Magento 2 Note**: While much of Magento 2's core code is distributed in the `vendor` folder, the `app/code` folder still works!

Remove Cache and Generated Files
--------------------------------------------------
The next step  is deleting your Magento cache, generated code, and serialized dependency injection files.  While the `module:enable` command (used below) *should* take care of this, it never hurts to do this yourself.

Assuming you're running with a stock system, you'll want to remove the contents of the following folders
 
    var/generation/* 
    var/cache/* 

and remove the following folder entirely (if it exists)
    
    var/di/

If you're running custom extensions for cache, code generation, or dependency injection serialization, please consult the manuals for those extensions on how how to clear their contents. 

Removing these files will definitely cause temporary instabilities in a production system.  Again, debugging tools like Commerce Bug are not intended or supported in production systems, and if circumstances force you to use them in production systems please take the necessary precautions. 

Enable and Setup the Commerce Bug Module
--------------------------------------------------
Next up: We need to enable the extension in Magento 2, and then run the extensions setup scripts. 

Enable your module using the Magento Command Line
    
    php bin/magento module:enable Packagename_Commercebug
    
Then refresh the setup upgrade database tables

    php bin/magento setup:upgrade

After performing the above, you should see Commerce Bug at the bottom of every Magento page. 

Remember -- Commerce Bug 3 for Magento 2 now obeys settings in 

    Stores -> Configuration -> Advanced -> Developer -> Developer Client Restrictions
    
So if you don't want your team to see the extension, use this setting to restrict access.  

Miscellaneous Notes on New Features
--------------------------------------------------
Commerce Bug 3 brings the same power of Commerce Bug 1 and 2 to Magento 2, and also adds new features!
    
Commerce Bug 3 for Magento 2 will log the last 10 requests.  You can find and review all the details of these requests at 

    System -> Other Settings -> Commerce Bug Logs
    
This feature is perfect for debugging AJAX, API, Mobile, or any other requests that don't render in a personal computer web browser UI.    
        
Commerce Bug 3's "Class Lookup" tab will allow you to lookup information (file location, ancestry chain, etc) on any PHP class/Magento object manager type in the system.     

Commerce Bug 3's Layout tab will now render a graph of the layout that includes color coding container, blocks, and UI components.  

Finally, if there's a feature from Commerce Bug 2 that you're missing or you think there's a new feature it should have, please get in touch with support.

    http://www.pulsestorm.net/contact-us/

These are early days, and we've only begun exploring the power and features of Magento 2. 